# Plants Disease Identifier

Disease classification in plants using CNN created in django project to classify new disease plants which predicts new data under accuracy of 96% which is trained under 20,000 
train images and 6,000 test images.

<h1>Demo of project</h1>

![ezgif com-video-to-gif](https://user-images.githubusercontent.com/35693682/87135930-7ae8bc80-c2ba-11ea-8097-d302fa350584.gif)

